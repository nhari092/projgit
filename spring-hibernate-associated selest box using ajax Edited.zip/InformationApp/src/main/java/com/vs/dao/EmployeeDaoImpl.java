package com.vs.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.vs.bean.CityName;
import com.vs.bean.Employee;
@Repository("EmployeeDao")
public class EmployeeDaoImpl implements EmployeeDao{
	@Autowired
HibernateTemplate ht=null;
	public void saveStudent(Employee s) {
ht.save(s);
		
	}//EmployeeDaoImpl()
	public List getCities(String state) {
		List<CityName> cityList= (List<CityName>) ht.find(" from CityName c where c.state=?", state);	
		return cityList;
	}//getCities	

}//EmployeeDaoImpl
