package com.vs.dao;

import java.util.List;

import com.vs.bean.Employee;

public interface EmployeeDao {
	public void saveStudent(Employee s) ;

	public List getCities(String state);

}
