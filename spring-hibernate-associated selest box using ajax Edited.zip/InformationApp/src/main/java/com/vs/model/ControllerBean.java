package com.vs.model;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.vs.bean.CityName;
import com.vs.bean.Employee;
import com.vs.dao.EmployeeDao;

@Controller
public class ControllerBean {
	@Autowired
	EmployeeDao dao=null;
	@RequestMapping(value="/addemp",method=RequestMethod.GET)
	public ModelAndView addEmployee(HttpServletRequest req){
		Employee s=setEmployee(req);
		dao.saveStudent(s);
		return new ModelAndView("response","message","EMPLOYEE IS ADDED TO DB");
		}//addEmployee()
	@RequestMapping( value="/getcity",method=RequestMethod.GET )
	public ModelAndView getCities(HttpServletRequest req){
    List<CityName> citieslist=dao.getCities(req.getParameter("state"));
	Object[] s=citieslist.toArray();
return new ModelAndView("for","cities",citieslist);
		
	}//getCities
	
	
	
	
	private Employee setEmployee(HttpServletRequest req) {
		Employee e=new Employee();
/*		e.setId(Integer.parseInt(req.getParameter("id")));
*/		e.setName(req.getParameter("empname"));
		e.setGender(req.getParameter("gender"));
		if(req.getParameter("maritalstatus")!=null ){
		e.setMaritalStatus("MARRIED");
		}//if
		else
		{
			e.setMaritalStatus("UNMARRIED");
		}//else
		if(req.getParameter("nationality")!=null ){
			e.setNationality("INDIAN");
			}//if
			else
			{
				e.setNationality("NON INDIAN");
			}//else
		e.setState(req.getParameter("state"));
		e.setCity(req.getParameter("city"));

		return e;		
		
	}//setEmployee
}//ControllerBean
