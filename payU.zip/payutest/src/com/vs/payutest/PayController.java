package com.vs.payutest;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/payController")
public class PayController extends HttpServlet {	
	PrintWriter pw=null;
	String merchant_key="qErhuP";
	String salt="VBnv924c";
RequestDispatcher rd=null;
String flag="";
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		resp.setContentType("text/html");
        pw=resp.getWriter();
		flag=req.getParameter("flag");
if(flag !=null)
		forwardPay(req, resp);
else
{
	   payReceiver(req, resp);

	}//else

	}//doGet()
	
	@Override	
	public  void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(req,resp);
	}//doPost()
	
 
	//receive payment from payu
	private void payReceiver(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String amount = req.getParameter("amount");
			String productinfo= req.getParameter("productinfo");
			String txnid = req.getParameter("txnid");
			String phone = req.getParameter("phone");
			String firstname = req.getParameter("firstname");
			String status = req.getParameter("status");
			String r_h =req.getParameter("hash");
		        String hashString="";
		        String hash;
		        String udf1 =req.getParameter("udf1");
		        String udf2 =req.getParameter("udf2");
		        String udf3 =req.getParameter("udf3");
		        String udf4 =req.getParameter("udf4");
		        String udf5 =req.getParameter("udf5");
		        String p_Id = req.getParameter("mihpayid");
		        String additionalCharges = req.getParameter("additionalCharges");
		        String email = req.getParameter("email");
		        if(status=="success"){
		        	//if additional charges are levied
		            if(additionalCharges!=null){
			String hashSequence = additionalCharges+"|"+salt+"|"+status+"||||||"+udf5+"|"+udf4+"|"+udf3+"|"+udf2+"|"+udf1+"|"+email+"|"+firstname+"|"+productinfo+"|"+amount+"|"+txnid+"|";
			
			
				hashString=hashSequence.concat(merchant_key);
		                    pw.println(hashString);
		                    hash=hashCal("SHA-512",hashString);
		                    pw.println(hash);
				if(r_h.equals(hash)){
			       
					String surl="/success.jsp?amount="+amount+"&additionalCharges="+additionalCharges+"&status="+status+"&txnid"+txnid;
					rd=req.getRequestDispatcher(surl);
					rd.forward(req, resp);
		                        }
				                  
		                    else {
		                    	
		                    	String surl="/successt.jsp?amount="+amount+"&additionalCharges="+additionalCharges+"&status="+status+"&txnid"+txnid;
		        				rd=req.getRequestDispatcher(surl);
		                    	rd.forward(req, resp);

		                    }//else
		            }//if
		        
		            //if no additional charges are levied
		            else {
		            String hashSequence = salt+"|"+status+"||||||"+udf5+"|"+udf4+"|"+udf3+"|"+udf2+"|"+udf1+"|"+email+"|"+firstname+"|"+productinfo+"|"+amount+"|"+txnid+"|";
			
			
				hashString=hashSequence.concat(merchant_key);
		                    pw.println(hashString);
		                    hash=hashCal("SHA-512",hashString);
		                    pw.println(hash);
				if(r_h.equals(hash)){
			       
					String surl="/success.jsp?amount="+amount+"&additionalCharges="+additionalCharges+"&status="+status+"&txnid"+txnid;
					rd=req.getRequestDispatcher(surl);
		        	rd.forward(req, resp);

		                        }
				                  
		                    else{ 
		                  
		                    	String surl="/success.jsp?amount="+amount+"&additionalCharges="+additionalCharges+"&status="+status+"&txnid"+txnid;
		        				rd=req.getRequestDispatcher(surl);
		                    	rd.forward(req, resp);

		                        }
		            }	
		    }else {
		    	
		    	String surl="/success.jsp?amount="+amount+"&additionalCharges="+additionalCharges+"&status="+status+"&txnid"+txnid;
				rd=req.getRequestDispatcher(surl);
		    	rd.forward(req, resp);
		                    }
	}
	
	//send payment request to payu
	private void forwardPay(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		//get all the names of parameters in request object
		Enumeration paramNames = req.getParameterNames();
		Map<String,String> params= new HashMap<String,String>();		
	    	while(paramNames.hasMoreElements()) 
		{
	      		String paramName = (String)paramNames.nextElement();
	      		String paramValue = req.getParameter(paramName);

	      		//place all the values of parameters in Map object(params)

			params.put(paramName,paramValue);
		}//while
			
	           //calling hashCall method to get txnid
	    	
			String txnid ="";
			Random rand = new Random();
			String rndm = Integer.toString(rand.nextInt())+(System.currentTimeMillis() / 1000L);
			txnid=hashCal("SHA-256",rndm).substring(0,20);	

params.put("key",merchant_key);
params.put("txnid",txnid);
		String hash="";
		String hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
		
				String[] hashVarSeq=hashSequence.split("\\|");
				String hashString=" ";
				//generate hasString with user credentials and send to hashCal method
				for(String part : hashVarSeq)
				{

					//concate value enterd by user to craete hash generation formula 
			  	   String temp= params.get(part);
			  	   if(temp !=null){
					hashString= hashString.concat(temp.trim());
					}//if
					hashString=hashString.concat("|");
				}//for
				//concate hash value to finally generated hashString
				hashString=hashString.concat(salt);

	           //calling hashCall method to get hash value
				 hash=hashCal("SHA-512",hashString.trim());		

req.setAttribute("key",merchant_key);
req.setAttribute("hash",hash);
req.setAttribute("txnid",txnid);
String url="/test.jsp?amount="+req.getParameter("amount")+"&firstname="+req.getParameter("firstname")+"&email="+req.getParameter("email")+"&phone="+req.getParameter("phone")+
"&productinfo="+req.getParameter("productinfo");
		 rd=req.getRequestDispatcher(url);
		rd.forward(req,resp);
	}//forwardPay
	
	
	//method to generate hash value and transaction id 
	public String hashCal(String type,String str){
		byte[] hashseq=str.getBytes();
		StringBuffer hexString = new StringBuffer();
		try{
		MessageDigest algorithm = MessageDigest.getInstance(type);
		algorithm.reset();
		algorithm.update(hashseq);
		byte messageDigest[] = algorithm.digest();
            
		

		for (int i=0;i<messageDigest.length;i++) {
			String hex=Integer.toHexString(0xFF & messageDigest[i]);
			if(hex.length()==1) hexString.append("0");
			hexString.append(hex);
		}
			
		}catch(NoSuchAlgorithmException nsae){ }
		
		return hexString.toString();
				
			
		}//hashCal()

}//class
