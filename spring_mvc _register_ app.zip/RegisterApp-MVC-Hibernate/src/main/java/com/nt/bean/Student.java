package com.nt.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="student")
public class Student implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	@Column(name="sid")
	@Id
	private int id;
	@Column(name="sname",length=15)
	private String name;
	@Column(name="sage",length=3)
	private int age;
	@Column(length=3)
	private float marks1;
	@Column(length=3)
    private float marks2;
	@Column(length=10)
    private String address;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getMarks1() {
		return marks1;
	}
	public void setMarks1(float marks1) {
		this.marks1 = marks1;
	}
	public float getMarks2() {
		return marks2;
	}
	public void setMarks2(float marks2) {
		this.marks2 = marks2;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
