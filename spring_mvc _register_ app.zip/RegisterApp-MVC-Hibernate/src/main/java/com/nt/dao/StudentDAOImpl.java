package com.nt.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.nt.bean.Student;
@Repository("studentDao")//used to give custom id
public class StudentDAOImpl implements IStudentDAO {
	@Autowired
	private HibernateTemplate ht;
	
	public void saveStudent(Student s) {
		ht.saveOrUpdate(s);
	}

	public Student getStudentById(int id) {
			Student s=ht.get(Student.class,id);
			return s;
	}

}
