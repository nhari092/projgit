package com.nt.dao;

import com.nt.bean.Student;

public interface IStudentDAO {
	public void saveStudent(Student s);
	public Student getStudentById(int id);

}
