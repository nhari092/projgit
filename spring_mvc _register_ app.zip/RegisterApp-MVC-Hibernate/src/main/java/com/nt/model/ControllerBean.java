package com.nt.model;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nt.bean.Student;
import com.nt.dao.IStudentDAO;

@Controller
public class ControllerBean {
	@Autowired
	IStudentDAO dao;
	@RequestMapping(value="/newstudent",method=RequestMethod.POST)
	public ModelAndView newStudent(HttpServletRequest req)
		{
		Student s=setStudent(req);
		dao.saveStudent(s);
		return new ModelAndView("response","message","STUDENT IS ADDED TO DB");
		}
	private Student setStudent(HttpServletRequest req) {
		Student s=new Student();
		try{
		s.setId(Integer.parseInt(req.getParameter("StudentId")));
		s.setName(req.getParameter("StudentName"));
		s.setAge(Integer.parseInt(req.getParameter("StudentAge")));
		s.setMarks1(Float.parseFloat(req.getParameter("Marks1")));
		s.setMarks2(Float.parseFloat(req.getParameter("Marks2")));
		s.setAddress(req.getParameter("Address"));
		}//try
		catch(NumberFormatException nfe){
			nfe.printStackTrace();			
		}//catch
		catch(Exception nfe){
			nfe.printStackTrace();			
		}//catch
		return s;
	}//setStudent()
	
	@RequestMapping(value="/getstudent",method=RequestMethod.GET)
	public ModelAndView getStudent(@RequestParam int id){
				//call dao method
			Student s=dao.getStudentById(id);
			
		return new ModelAndView("studentdata","student",s);
		
	}
	

}//class
